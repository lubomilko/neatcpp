# pylint: disable = missing-module-docstring
from neatcpp import run_console_app


run_console_app()
